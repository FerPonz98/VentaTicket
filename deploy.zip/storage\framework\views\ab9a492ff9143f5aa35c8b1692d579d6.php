


<?php $__env->startSection('title', 'Registrar Nuevo Usuario'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mx-auto p-6">
  <a href="<?php echo e(route('users.index')); ?>"
     class="inline-block mb-4 text-sm text-blue-600 hover:underline">
    ← Volver al listado
  </a>

  <div class="bg-white shadow-lg rounded-lg p-6">
    <h2 class="text-2xl font-bold mb-6 text-black">
      Registrar Nuevo Usuario
    </h2>

    <?php if($errors->any()): ?>
      <div class="mb-6 p-4 bg-red-100 border border-red-300 text-red-800 rounded">
        <p class="font-semibold">Por favor corrige los siguientes errores:</p>
        <ul class="list-disc list-inside mt-2">
          <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      </div>
    <?php endif; ?>

    <form action="<?php echo e(route('users.store')); ?>" method="POST" enctype="multipart/form-data">
      <?php echo csrf_field(); ?>

      <div class="grid grid-cols-1 md:grid-cols-2 gap-6 text-black">
        
        <div>
          <label class="block font-semibold mb-1">CI Usuario</label>
          <input type="text" name="ci_usuario" value="<?php echo e(old('ci_usuario')); ?>"
                 class="w-full bg-gray-100 border rounded px-3 py-2" required>
          <?php $__errorArgs = ['ci_usuario'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-600 text-sm mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        
        <div>
          <label class="block font-semibold mb-1">Nombre de Usuario</label>
          <input type="text" name="nombre_usuario" value="<?php echo e(old('nombre_usuario')); ?>"
                 class="w-full bg-gray-100 border rounded px-3 py-2" required>
          <?php $__errorArgs = ['nombre_usuario'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-600 text-sm mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        
        <div>
          <label class="block font-semibold mb-1">Apellidos</label>
          <input type="text" name="apellidos" value="<?php echo e(old('apellidos')); ?>"
                 class="w-full bg-gray-100 border rounded px-3 py-2" required>
          <?php $__errorArgs = ['apellidos'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-600 text-sm mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        
        <div>
          <label class="block font-semibold mb-1">Sexo</label>
          <select name="sexo" class="w-full bg-gray-100 border rounded px-3 py-2" required>
            <option value="">-- Seleccione --</option>
            <option value="masculino" <?php echo e(old('sexo')=='masculino'?'selected':''); ?>>Masculino</option>
            <option value="femenino"  <?php echo e(old('sexo')=='femenino' ?'selected':''); ?>>Femenino</option>
          </select>
          <?php $__errorArgs = ['sexo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-600 text-sm mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        
        <div>
          <label class="block font-semibold mb-1">Fecha de Nacimiento</label>
          <input type="date" name="fecha_nacimiento" value="<?php echo e(old('fecha_nacimiento')); ?>"
                 class="w-full bg-gray-100 border rounded px-3 py-2" required>
          <?php $__errorArgs = ['fecha_nacimiento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-600 text-sm mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        
        <div>
          <label class="block font-semibold mb-1">Estado</label>
          <select name="estado" class="w-full bg-gray-100 border rounded px-3 py-2" required>
            <option value="activo"   <?php echo e(old('estado')=='activo'   ?'selected':''); ?>>Activo</option>
            <option value="inactivo" <?php echo e(old('estado')=='inactivo' ?'selected':''); ?>>Inactivo</option>
          </select>
          <?php $__errorArgs = ['estado'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-600 text-sm mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        
        <div>
          <label class="block font-semibold mb-1">Estado Civil</label>
          <select name="estado_civil" class="w-full bg-gray-100 border rounded px-3 py-2" required>
            <option value="soltero"    <?php echo e(old('estado_civil')=='soltero'    ?'selected':''); ?>>Soltero/a</option>
            <option value="casado"     <?php echo e(old('estado_civil')=='casado'     ?'selected':''); ?>>Casado/a</option>
            <option value="viudo"      <?php echo e(old('estado_civil')=='viudo'      ?'selected':''); ?>>Viudo/a</option>
            <option value="divorciado" <?php echo e(old('estado_civil')=='divorciado' ?'selected':''); ?>>Divorciado/a</option>
          </select>
          <?php $__errorArgs = ['estado_civil'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-600 text-sm mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        
        <div>
          <label class="block font-semibold mb-1">Lugar de Residencia</label>
          <input type="text" name="lugar_residencia" value="<?php echo e(old('lugar_residencia')); ?>"
                 class="w-full bg-gray-100 border rounded px-3 py-2" required>
          <?php $__errorArgs = ['lugar_residencia'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-600 text-sm mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        
        <div>
          <label class="block font-semibold mb-1">Domicilio</label>
          <input type="text" name="domicilio" value="<?php echo e(old('domicilio')); ?>"
                 class="w-full bg-gray-100 border rounded px-3 py-2" required>
          <?php $__errorArgs = ['domicilio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-600 text-sm mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        
        <div>
          <label class="block font-semibold mb-1">Correo Electrónico</label>
          <input type="email" name="email" value="<?php echo e(old('email')); ?>"
                 class="w-full bg-gray-100 border rounded px-3 py-2" required>
          <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-600 text-sm mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        
        <div>
          <label class="block font-semibold mb-1">Celular</label>
          <input type="text" name="celular" value="<?php echo e(old('celular')); ?>"
                 class="w-full bg-gray-100 border rounded px-3 py-2">
          <?php $__errorArgs = ['celular'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-600 text-sm mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        
        <div class="md:col-span-2">
          <label class="block font-semibold mb-1">Referencias</label>
          <textarea name="referencias" rows="3"
                    class="w-full bg-gray-100 border rounded px-3 py-2"><?php echo e(old('referencias')); ?></textarea>
          <?php $__errorArgs = ['referencias'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-600 text-sm mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        
        <div>
          <label class="block font-semibold mb-1">Rol</label>
          <select name="rol" class="w-full bg-gray-100 border rounded px-3 py-2" required>
            <option value="">-- Seleccione --</option>
            <option value="admin"           <?php echo e(old('rol')=='admin'           ?'selected':''); ?>>Admin</option>
            <option value="supervisor gral" <?php echo e(old('rol')=='supervisor gral' ?'selected':''); ?>>Supervisor Gral</option>
            <option value="supervisor suc"  <?php echo e(old('rol')=='supervisor suc'  ?'selected':''); ?>>Supervisor SUC</option>
            <option value="cajero"          <?php echo e(old('rol')=='cajero'          ?'selected':''); ?>>Cajero</option>
            <option value="ventas qr"       <?php echo e(old('rol')=='ventas qr'       ?'selected':''); ?>>Ventas QR</option>
            <option value="carga"           <?php echo e(old('rol')=='carga'           ?'selected':''); ?>>Carga</option>
            <option value="encomienda"      <?php echo e(old('rol')=='encomienda'      ?'selected':''); ?>>Encomienda</option>
            <option value="chofer y ayudante" <?php echo e(old('rol')=='chofer y ayudante' ?'selected':''); ?>>Chofer y Ayudante</option>
          </select>
          <?php $__errorArgs = ['rol'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-600 text-sm mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        
        <div>
          <label class="block font-semibold mb-1">Contraseña</label>
          <input type="password" name="password"
                 class="w-full bg-gray-100 border rounded px-3 py-2" required>
          <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-600 text-sm mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        
        <div>
          <label class="block font-semibold mb-1">Confirmar Contraseña</label>
          <input type="password" name="password_confirmation"
                 class="w-full bg-gray-100 border rounded px-3 py-2" required>
        </div>

        
        <div>
          <label class="block font-semibold mb-1">Pregunta de Seguridad</label>
          <select name="security_question"
                  class="w-full bg-gray-100 border rounded px-3 py-2" required>
            <option value="">-- Seleccione --</option>
            <option value="color"    <?php echo e(old('security_question')=='color'    ?'selected':''); ?>>¿Cuál es tu color favorito?</option>
            <option value="mascota"  <?php echo e(old('security_question')=='mascota'  ?'selected':''); ?>>¿Cómo se llamaba tu primera mascota?</option>
            <option value="ciudad"   <?php echo e(old('security_question')=='ciudad'   ?'selected':''); ?>>¿Dónde naciste?</option>
            <option value="comida"   <?php echo e(old('security_question')=='comida'   ?'selected':''); ?>>¿Cuál es tu comida favorita?</option>
          </select>
          <?php $__errorArgs = ['security_question'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-600 text-sm mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        
        <div>
          <label class="block font-semibold mb-1">Respuesta de Seguridad</label>
          <input type="text" name="security_answer" value="<?php echo e(old('security_answer')); ?>"
                 class="w-full bg-gray-100 border rounded px-3 py-2" required>
          <?php $__errorArgs = ['security_answer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-600 text-sm mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        
        <div>
          <label class="block font-semibold mb-1">Fotografía (jpg, png o pdf)</label>
          <input type="file" name="foto" accept=".jpg,.jpeg,.png,.pdf"
                 class="w-full bg-gray-100 border rounded px-3 py-2">
          <?php $__errorArgs = ['foto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-600 text-sm mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        
        <?php for($i=1; $i<=5; $i++): ?>
          <div>
            <label class="block font-semibold mb-1">Documento <?php echo e($i); ?> (jpg, png o pdf)</label>
            <input type="file" name="documento_<?php echo e($i); ?>" accept=".jpg,.jpeg,.png,.pdf"
                   class="w-full bg-gray-100 border rounded px-3 py-2">
            <?php $__errorArgs = ["documento_$i"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-600 text-sm mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
        <?php endfor; ?>

      </div>

      <div class="mt-6 text-right">
        <button type="submit"
                class="px-6 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 transition">
          Registrar Usuario
        </button>
      </div>
    </form>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\VentaTicket\resources\views/admin/users/create.blade.php ENDPATH**/ ?>