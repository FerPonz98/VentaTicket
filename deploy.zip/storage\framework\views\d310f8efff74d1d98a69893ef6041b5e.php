


<?php $__env->startSection('title', 'Editar Usuario'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mx-auto mt-6">
  <a href="<?php echo e(route('users.index')); ?>"
     class="inline-block mb-4 text-sm text-blue-600 hover:underline">
    ← Volver al listado
  </a>

  <div class="bg-white shadow rounded-lg p-6">
    <h2 class="text-2xl font-bold mb-6 text-black">
      Editar Usuario: <?php echo e($usuario->ci_usuario); ?>

    </h2>

    <form action="<?php echo e(route('users.update', $usuario->ci_usuario)); ?>"
          method="POST"
          enctype="multipart/form-data">
      <?php echo csrf_field(); ?>
      <?php echo method_field('PATCH'); ?>

      <div class="grid grid-cols-1 md:grid-cols-2 gap-6 text-black">
        
        <div>
          <label class="block font-semibold mb-1">CI</label>
          <input type="text" value="<?php echo e($usuario->ci_usuario); ?>" readonly
                 class="w-full bg-gray-100 border rounded px-3 py-2 cursor-not-allowed"/>
        </div>

        
        <div>
          <label class="block font-semibold mb-1">Nombre</label>
          <input name="nombre_usuario"
                 value="<?php echo e(old('nombre_usuario', $usuario->nombre_usuario)); ?>"
                 class="w-full bg-gray-100 border rounded px-3 py-2"/>
          <?php $__errorArgs = ['nombre_usuario'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-600 text-sm"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        
        <div>
          <label class="block font-semibold mb-1">Apellidos</label>
          <input name="apellidos"
                 value="<?php echo e(old('apellidos', $usuario->apellidos)); ?>"
                 class="w-full bg-gray-100 border rounded px-3 py-2"/>
          <?php $__errorArgs = ['apellidos'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-600 text-sm"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        
        <div>
          <label class="block font-semibold mb-1">Sexo</label>
          <select name="sexo"
                  class="w-full bg-gray-100 border rounded px-3 py-2">
            <option value="masculino" <?php echo e(old('sexo',$usuario->sexo)=='M'?'selected':''); ?>>Masculino</option>
            <option value="femenino"  <?php echo e(old('sexo',$usuario->sexo)=='F'?'selected':''); ?>>Femenino</option>
          </select>
          <?php $__errorArgs = ['sexo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-600 text-sm"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        
        <div>
          <label class="block font-semibold mb-1">Fecha de Nacimiento</label>
          <input type="date" name="fecha_nacimiento"
                 value="<?php echo e(old('fecha_nacimiento', $usuario->fecha_nacimiento)); ?>"
                 class="w-full bg-gray-100 border rounded px-3 py-2"/>
          <?php $__errorArgs = ['fecha_nacimiento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-600 text-sm"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        
        <div>
          <label class="block font-semibold mb-1">Estado</label>
          <select name="estado"
                  class="w-full bg-gray-100 border rounded px-3 py-2">
            <option value="activo"    <?php echo e(old('estado',$usuario->estado)=='activo'?'selected':''); ?>>Activo</option>
            <option value="bloqueado" <?php echo e(old('estado',$usuario->estado)=='bloqueado'?'selected':''); ?>>Bloqueado</option>
          </select>
          <?php $__errorArgs = ['estado'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-600 text-sm"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        
        <div>
          <label class="block font-semibold mb-1">Estado Civil</label>
          <select name="estado_civil"
                  class="w-full bg-gray-100 border rounded px-3 py-2">
            <option value="soltero" <?php echo e(old('estado_civil',$usuario->estado_civil)=='soltero'?'selected':''); ?>>Soltero/a</option>
            <option value="casado"  <?php echo e(old('estado_civil',$usuario->estado_civil)=='casado'?'selected':''); ?>>Casado/a</option>
            <option value="viudo"   <?php echo e(old('estado_civil',$usuario->estado_civil)=='viudo'?'selected':''); ?>>Viudo/a</option>
          </select>
          <?php $__errorArgs = ['estado_civil'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-600 text-sm"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        
        <div>
          <label class="block font-semibold mb-1">Lugar de Residencia</label>
          <input name="lugar_residencia"
                 value="<?php echo e(old('lugar_residencia', $usuario->lugar_residencia)); ?>"
                 class="w-full bg-gray-100 border rounded px-3 py-2"/>
          <?php $__errorArgs = ['lugar_residencia'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-600 text-sm"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        
        <div>
          <label class="block font-semibold mb-1">Domicilio</label>
          <input name="domicilio"
                 value="<?php echo e(old('domicilio', $usuario->domicilio)); ?>"
                 class="w-full bg-gray-100 border rounded px-3 py-2"/>
          <?php $__errorArgs = ['domicilio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-600 text-sm"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        
        <div>
          <label class="block font-semibold mb-1">Email</label>
          <input type="email" name="email"
                 value="<?php echo e(old('email', $usuario->email)); ?>"
                 class="w-full bg-gray-100 border rounded px-3 py-2"/>
          <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-600 text-sm"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        
        <div>
          <label class="block font-semibold mb-1">Celular</label>
          <input name="celular"
                 value="<?php echo e(old('celular', $usuario->celular)); ?>"
                 class="w-full bg-gray-100 border rounded px-3 py-2"/>
          <?php $__errorArgs = ['celular'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-600 text-sm"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        
        <div class="md:col-span-2">
          <label class="block font-semibold mb-1">Referencias</label>
          <textarea name="referencias" rows="3"
                    class="w-full bg-gray-100 border rounded px-3 py-2"><?php echo e(old('referencias', $usuario->referencias)); ?></textarea>
          <?php $__errorArgs = ['referencias'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-600 text-sm"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        
        <div>
            <label class="block font-semibold mb-1">Rol</label>
            <select name="rol" class="w-full bg-gray-100 border rounded px-3 py-2 text-black">
                <option value="admin"             <?php echo e(old('rol', $usuario->rol)=='admin'             ? 'selected':''); ?>>Admin</option>
                <option value="supervisor gral"   <?php echo e(old('rol', $usuario->rol)=='supervisor gral'   ? 'selected':''); ?>>Supervisor Gral</option>
                <option value="supervisor suc"    <?php echo e(old('rol', $usuario->rol)=='supervisor suc'    ? 'selected':''); ?>>Supervisor SUC</option>
                <option value="cajero"            <?php echo e(old('rol', $usuario->rol)=='cajero'            ? 'selected':''); ?>>Cajero</option>
                <option value="chofer y ayudante" <?php echo e(old('rol', $usuario->rol)=='chofer y ayudante' ? 'selected':''); ?>>Chofer y Ayudante</option>
                <option value="carga"             <?php echo e(old('rol', $usuario->rol)=='carga'             ? 'selected':''); ?>>Carga</option>
                <option value="ventas qr"         <?php echo e(old('rol', $usuario->rol)=='ventas qr'         ? 'selected':''); ?>>Ventas QR</option>
                <option value="encomienda"        <?php echo e(old('rol', $usuario->rol)=='encomienda'        ? 'selected':''); ?>>Encomienda</option>
            </select>
            <?php $__errorArgs = ['rol'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-600 text-sm"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        
        <div class="md:col-span-2">
          <label class="block font-semibold mb-1">Foto</label>

          <?php if($usuario->foto): ?>
            <div class="flex items-center justify-between mb-2">
              <a href="<?php echo e(asset('storage/'.$usuario->foto)); ?>"
                 target="_blank"
                 class="text-blue-600 hover:underline">
                Ver foto
              </a>
              <label class="inline-flex items-center">
                <input type="checkbox"
                       name="remove_foto"
                       value="1"
                       class="form-checkbox mr-1">
                <span class="text-red-600 font-medium">Eliminar</span>
              </label>
            </div>
            <img src="<?php echo e(asset('storage/'.$usuario->foto)); ?>"
                 alt="Foto de <?php echo e($usuario->nombre_usuario); ?>"
                 class="w-64 h-64 object-cover rounded-lg border mb-4">
          <?php endif; ?>

          <input type="file"
                 name="foto"
                 accept=".jpg,.jpeg,.png,.pdf"
                 class="w-full bg-gray-100 border rounded px-3 py-2"/>
          <?php $__errorArgs = ['foto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-600 text-sm"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        
        <?php for($i=1; $i<=5; $i++): ?>
          <div>
            <label class="block font-semibold mb-1">Documento <?php echo e($i); ?></label>

            <?php if($usuario["documento_$i"]): ?>
              <div class="flex items-center justify-between mb-2">
                <a href="<?php echo e(asset('storage/'.$usuario["documento_$i"])); ?>"
                   target="_blank"
                   class="text-blue-600 hover:underline">
                  Ver documento <?php echo e($i); ?>

                </a>
                <label class="inline-flex items-center">
                  <input type="checkbox"
                         name="remove_documento_<?php echo e($i); ?>"
                         value="1"
                         class="form-checkbox mr-1">
                  <span class="text-red-600 font-medium">Eliminar</span>
                </label>
              </div>
            <?php endif; ?>

            <input type="file"
                   name="documento_<?php echo e($i); ?>"
                   accept=".pdf,.jpg,.jpeg,.png"
                   class="w-full bg-gray-100 border rounded px-3 py-2"/>
            <?php $__errorArgs = ["documento_$i"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-600 text-sm"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
        <?php endfor; ?>

        
        <div class="md:col-span-2">
          <label class="block font-semibold mb-1">Pregunta de Seguridad</label>
          <select name="security_question"
                  class="w-full bg-gray-100 border rounded px-3 py-2">
            <option value="">-- Selecciona una pregunta --</option>
            <option value="¿Color favorito?"       <?php echo e(old('security_question',$usuario->security_question)=='¿Color favorito?'?'selected':''); ?>>¿Color favorito?</option>
            <option value="¿Nombre de tu mascota?" <?php echo e(old('security_question',$usuario->security_question)=='¿Nombre de tu mascota?'?'selected':''); ?>>¿Nombre de tu mascota?</option>
            <option value="¿Ciudad de nacimiento?" <?php echo e(old('security_question',$usuario->security_question)=='¿Ciudad de nacimiento?'?'selected':''); ?>>¿Ciudad de nacimiento?</option>
            <option value="¿Comida favorita?"      <?php echo e(old('security_question',$usuario->security_question)=='¿Comida favorita?'?'selected':''); ?>>¿Comida favorita?</option>
          </select>
          <?php $__errorArgs = ['security_question'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-600 text-sm"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        
        <div>
          <label class="block font-semibold mb-1">Respuesta de Seguridad</label>
          <input name="security_answer"
                 value="<?php echo e(old('security_answer', $usuario->security_answer)); ?>"
                 class="w-full bg-gray-100 border rounded px-3 py-2"/>
          <?php $__errorArgs = ['security_answer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-600 text-sm"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        
        <div class="md:col-span-2">
          <label class="block font-semibold mb-1">Actualizar Contraseña (opcional)</label>
          <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
            <input type="password"
                   name="password"
                   placeholder="Nueva contraseña"
                   class="w-full bg-gray-100 border rounded px-3 py-2"/>
            <input type="password"
                   name="password_confirmation"
                   placeholder="Confirmar contraseña"
                   class="w-full bg-gray-100 border rounded px-3 py-2"/>
          </div>
          <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-600 text-sm"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
      </div>

      
      <div class="mt-6 text-right">
        <button type="submit"
                class="px-6 py-2 bg-green-600 text-white rounded hover:bg-green-700">
          Actualizar Usuario
        </button>
      </div>
    </form>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\VentaTicket\resources\views/admin/users/edit.blade.php ENDPATH**/ ?>