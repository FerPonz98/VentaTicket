<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class AyudanteController extends Controller
{
    //
}
