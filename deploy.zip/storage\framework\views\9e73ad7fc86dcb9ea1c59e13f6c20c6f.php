<!DOCTYPE html>
<html lang="es" class="h-full bg-gray-100">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title><?php echo $__env->yieldContent('title','Mi App'); ?></title>
  <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css','resources/js/app.js']); ?>
</head>
<body class="h-full flex">
  <aside class="w-64 bg-gray-800 text-gray-200 flex flex-col">
    <div class="p-6 flex items-center">
      <img src="<?php echo e(asset('img/logo-empresa.jpg')); ?>" alt="Logo Empresa" class="h-8 w-auto"/>
      <span class="ml-2 font-bold text-lg">Mi Sistema</span>
    </div>
    <nav class="flex-1 overflow-y-auto">
      <ul class="space-y-1 px-4">
        <li><a href="<?php echo e(route('dashboard')); ?>" class="block px-3 py-2 rounded hover:bg-gray-700">Dashboard</a></li>
        <?php if(auth()->guard()->check()): ?>
          <?php if(in_array(Auth::user()->rol, ['admin','supervisor gral','supervisor suc'])): ?>
            <li><a href="<?php echo e(route('users.index')); ?>" class="block px-3 py-2 rounded hover:bg-gray-700">Usuarios</a></li>
          <?php endif; ?>
          <?php if(in_array(Auth::user()->rol, ['admin','supervisor gral','supervisor suc','cajero'])): ?>
            <li><a href="<?php echo e(route('pasajes.index')); ?>" class="block px-3 py-2 rounded hover:bg-gray-700">Pasajes</a></li>
          <?php endif; ?>
          <?php if(in_array(Auth::user()->rol, ['admin','supervisor gral','carga'])): ?>
            <li><a href="<?php echo e(route('carga.index')); ?>" class="block px-3 py-2 rounded hover:bg-gray-700">Carga</a></li>
          <?php endif; ?>
          <?php if(in_array(Auth::user()->rol, ['admin','supervisor gral','encomienda'])): ?>
            <li><a href="<?php echo e(route('encomiendas.index')); ?>" class="block px-3 py-2 rounded hover:bg-gray-700">Encomiendas</a></li>
          <?php endif; ?>
          <?php if(Auth::user()->rol === 'chofer y ayudante'): ?>
            <li><a href="<?php echo e(route('kardex.index')); ?>" class="block px-3 py-2 rounded hover:bg-gray-700">Kardex</a></li>
          <?php endif; ?>
          <?php if(in_array(Auth::user()->rol, ['admin','supervisor gral'])): ?>
            <li x-data="{ open: false }" class="group">
              <button @click="open = !open" class="w-full flex justify-between items-center px-3 py-2 rounded hover:bg-gray-700">
                <span>Buses</span>
                <svg :class="{ 'rotate-180': open }" class="h-4 w-4 transition-transform" viewBox="0 0 20 20" fill="currentColor">
                  <path d="M5.23 7.21l4.25 4.25 4.25-4.25"/>
                </svg>
              </button>
              <ul x-show="open" class="mt-1 pl-6 space-y-1">
                <li><a href="<?php echo e(route('buses.index')); ?>" class="block px-2 py-1 rounded hover:bg-gray-700">Listar Buses</a></li>
                <li><a href="<?php echo e(route('buses.create')); ?>" class="block px-2 py-1 rounded hover:bg-gray-700">Crear Bus</a></li>
              </ul>
            </li>
            <li x-data="{ open: false }" class="group">
              <button @click="open = !open" class="w-full flex justify-between items-center px-3 py-2 rounded hover:bg-gray-700">
                <span>Rutas</span>
                <svg :class="{ 'rotate-180': open }" class="h-4 w-4 transition-transform" viewBox="0 0 20 20" fill="currentColor">
                  <path d="M5.23 7.21l4.25 4.25 4.25-4.25"/>
                </svg>
              </button>
              <ul x-show="open" class="mt-1 pl-6 space-y-1">
                <li><a href="<?php echo e(route('rutas.index')); ?>" class="block px-2 py-1 rounded hover:bg-gray-700">Listar Rutas</a></li>
                <li><a href="<?php echo e(route('rutas.create')); ?>" class="block px-2 py-1 rounded hover:bg-gray-700">Crear Ruta</a></li>
              </ul>
            </li>
            <li x-data="{ open: false }" class="group">
              <button @click="open = !open" class="w-full flex justify-between items-center px-3 py-2 rounded hover:bg-gray-700">
                <span>Viajes</span>
                <svg :class="{ 'rotate-180': open }" class="h-4 w-4 transition-transform" viewBox="0 0 20 20" fill="currentColor">
                  <path d="M5.23 7.21l4.25 4.25 4.25-4.25"/>
                </svg>
              </button>
              <ul x-show="open" class="mt-1 pl-6 space-y-1">
                <li><a href="<?php echo e(route('viajes.index')); ?>" class="block px-2 py-1 rounded hover:bg-gray-700">Listar Viajes</a></li>
                <li><a href="<?php echo e(route('viajes.create')); ?>" class="block px-2 py-1 rounded hover:bg-gray-700">Crear Viaje</a></li>
              </ul>
            </li>
            <li x-data="{ open: false }" class="group">
              <button @click="open = !open" class="w-full flex justify-between items-center px-3 py-2 rounded hover:bg-gray-700">
                <span>Choferes</span>
                <svg :class="{ 'rotate-180': open }" class="h-4 w-4 transition-transform" viewBox="0 0 20 20" fill="currentColor">
                  <path d="M5.23 7.21l4.25 4.25 4.25-4.25"/>
                </svg>
              </button>
              <ul x-show="open" class="mt-1 pl-6 space-y-1">
                <li><a href="<?php echo e(route('choferes.index')); ?>" class="block px-2 py-1 rounded hover:bg-gray-700">Listar Choferes</a></li>
                <li><a href="<?php echo e(route('choferes.create')); ?>" class="block px-2 py-1 rounded hover:bg-gray-700">Crear Chofer</a></li>
              </ul>
            </li>
          <?php endif; ?>
        <?php endif; ?>
      </ul>
    </nav>
    <div class="p-4 border-t border-gray-700">
      <div class="flex items-center space-x-3">
        <?php if(Auth::user()->foto): ?>
          <img src="<?php echo e(asset('storage/' . Auth::user()->foto)); ?>"
               alt="Avatar de <?php echo e(Auth::user()->nombre_usuario); ?>"
               class="h-8 w-8 rounded-full object-cover"/>
        <?php else: ?>
          <div class="h-8 w-8 bg-gray-600 rounded-full"></div>
        <?php endif; ?>
        <div class="flex flex-col">
          <span class="text-sm font-medium text-white"><?php echo e(Auth::user()->nombre_usuario); ?></span>
          <span class="text-xs text-gray-400"><?php echo e(ucfirst(Auth::user()->rol)); ?></span>
          <form method="POST" action="<?php echo e(route('logout')); ?>" class="mt-1">
            <?php echo csrf_field(); ?>
            <button type="submit" class="text-xs text-gray-400 hover:underline">Salir</button>
          </form>
        </div>
      </div>
    </div>
  </aside>
  <div class="flex-1 flex flex-col overflow-hidden">
    <header class="bg-white shadow px-6 py-4 flex items-center justify-between">
      <h1 class="text-2xl font-semibold text-gray-800"><?php echo $__env->yieldContent('title'); ?></h1>
      <?php echo $__env->yieldContent('breadcrumbs'); ?>
    </header>
    <main class="flex-1 overflow-auto p-6">
      <?php echo $__env->yieldContent('content'); ?>
    </main>
  </div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\VentaTicket\resources\views/layouts/app.blade.php ENDPATH**/ ?>