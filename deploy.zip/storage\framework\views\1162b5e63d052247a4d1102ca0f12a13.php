


<?php $__env->startSection('title', 'Usuarios y Roles'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mx-auto mt-6">
    <h2 class="text-2xl font-bold mb-4 text-black">Listado de Usuarios</h2>

    <?php if(session('success')): ?>
        <div class="mb-4 p-2 bg-green-100 text-green-800 rounded">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <a href="<?php echo e(route('users.create')); ?>"
       class="inline-block mb-4 px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">
         Registrar nuevo usuario
    </a>

    <div class="overflow-x-auto">
        <table class="min-w-full bg-white border text-black">
            <thead class="bg-gray-100">
                <tr>
                    <th class="px-4 py-2 border text-black">CI</th>
                    <th class="px-4 py-2 border text-black">Nombre</th>
                    <th class="px-4 py-2 border text-black">Apellidos</th>
                    <th class="px-4 py-2 border text-black">Rol</th>
                    <th class="px-4 py-2 border text-black">Email</th>
                    <th class="px-4 py-2 border text-black">Foto</th>
                    <th class="px-4 py-2 border text-black">Estado</th>
                    <th class="px-4 py-2 border text-black">Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="<?php if($usuario->estado == 'bloqueado'): ?> bg-red-50 <?php endif; ?>">
                        <td class="px-4 py-2 border text-black"><?php echo e($usuario->ci_usuario); ?></td>
                        <td class="px-4 py-2 border text-black"><?php echo e($usuario->nombre_usuario); ?></td>
                        <td class="px-4 py-2 border text-black"><?php echo e($usuario->apellidos); ?></td>
                        <td class="px-4 py-2 border text-black"><?php echo e($usuario->rol); ?></td>
                        <td class="px-4 py-2 border text-black"><?php echo e($usuario->email); ?></td>
                        <td class="px-4 py-2 border text-black">
                            <?php if($usuario->foto): ?>
                                <img src="<?php echo e(asset('storage/'.$usuario->foto)); ?>" width="50" alt="">
                            <?php else: ?>
                                No tiene
                            <?php endif; ?>
                        </td>
                        <td class="px-4 py-2 border text-black"><?php echo e(ucfirst($usuario->estado)); ?></td>
                        <td class="px-4 py-2 border space-x-2">
                            <a href="<?php echo e(route('users.show', $usuario)); ?>" class="text-green-600 hover:underline">Ver</a>
                            <a href="<?php echo e(route('users.edit', $usuario)); ?>" class="text-blue-600 hover:underline">Editar</a>
                            <form method="POST" action="<?php echo e(route('users.destroy', $usuario)); ?>" class="inline">
                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="text-red-600 hover:underline">Eliminar</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="8" class="px-4 py-2 text-center text-black">No hay usuarios registrados.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\VentaTicket\resources\views/admin/users/index.blade.php ENDPATH**/ ?>