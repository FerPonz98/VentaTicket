<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <h1>Panel de Administración</h1>
    <p>Bienvenido, <?php echo e(auth()->user()->nombre_usuario); ?>!</p>

    <div class="card mt-4">
        <div class="card-body">
            <h5 class="card-title">Resumen</h5>
            <p class="card-text">Aquí puedes mostrar datos importantes, estadísticas o enlaces rápidos.</p>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\VentaTicket\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>